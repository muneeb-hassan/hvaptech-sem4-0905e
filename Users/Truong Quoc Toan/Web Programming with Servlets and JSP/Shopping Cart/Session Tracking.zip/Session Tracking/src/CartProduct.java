
public class CartProduct {
    
    public CartProduct() {
        
    }
    
    public CartProduct(Integer rowNo, String productName, Integer quantity) {
        this.rowNo = rowNo;
        this.productName = productName;
        this.quantity = quantity;
    }
    
    public Integer getRowNo() {
        return rowNo;
    }
    public void setRowNo(Integer rowNo) {
        this.rowNo = rowNo;
    }
    public String getProductName() {
        return productName;
    }
    public void setProductName(String productName) {
        this.productName = productName;
    }
    public Integer getQuantity() {
        return quantity;
    }
    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }
    
    private Integer rowNo;
    private String productName;
    private Integer quantity;

}
