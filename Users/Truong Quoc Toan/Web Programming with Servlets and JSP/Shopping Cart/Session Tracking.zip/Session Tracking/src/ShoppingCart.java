

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ShoppingCart
 */
public class ShoppingCart extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private List<CartProduct> listCartProducts;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShoppingCart() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        try {
            String mode = request.getParameter("mode").toString();
            String productName = request.getParameter("cbxProducts").toString();
            HttpSession session = request.getSession(true);
            this.listCartProducts = (List<CartProduct>) session.getAttribute("ListCartProducts");
            
            PrintWriter out = response.getWriter();

            if ("View cart".equals(mode)) {
                this.viewCart(out);
            } else if ("Add to cart".equals(mode)) {
                if (this.listCartProducts==null) {
                    this.listCartProducts = new ArrayList<CartProduct>();
                    CartProduct cartProduct = new CartProduct(1, productName, 1);
                    this.listCartProducts.add(cartProduct);
                } else {
                    boolean flag = false;
                    for (CartProduct cartProduct : this.listCartProducts) {
                        if (productName.equals(cartProduct.getProductName())) {
                            int productIndex = this.listCartProducts
                                    .indexOf(cartProduct);
                            int newQuantity = cartProduct.getQuantity() + 1;
                            cartProduct.setQuantity(newQuantity);
                            this.listCartProducts
                                    .set(productIndex, cartProduct);
                            flag = true;
                            break;
                        }
                    }
                    if (flag == false) {
                    	int rowNo = this.listCartProducts.size() + 1;
                        CartProduct cartProduct = new CartProduct(rowNo,
                                productName, 1);
                        this.listCartProducts.add(cartProduct);
                    }
                }
                session.setAttribute("ListCartProducts", this.listCartProducts);
                this.viewCart(out);
            }
            //response.sendRedirect("ShowCart.jsp");
        } catch (Exception e) {
            // TODO: handle exception
        }
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}
	
	// print result into ShowCart.jsp page
	private void viewCart(PrintWriter out){
	    
        if (listCartProducts==null) {
            try {
                // TODO output your page here

                out.println("<html>");
                out.println("<head>");
                out.println("<title>View Cart</title>");
                out.println("</head>");
                out.println("<body>");
                out.println("<h1>There is no product</h1>");
                out.println("<a href=\"/Session Tracking/Shopping.jsp\">Back to product page</a>");
                out.println("</body>");
                out.println("</html>");
            } catch (Exception e) {
                // TODO: handle exception
            } finally {
                out.close();
            }
        } else {
            try {
                // TODO output your page here

                out.println("<html>");
                out.println("<head>");
                out.println("<title>View Cart</title>");
                out.println("</head>");
                out.println("<body>");
                out.println("<h1>Your Cart:</h1>");
                out.println("<Table border=\"1\" bordercolor=\"black\" >");
                out.println("<tr><td>Row No</td><td>Product Name</td><td>Quantity</td></tr>");
                for (CartProduct cartProduct : this.listCartProducts) {
                    out.println("<tr><td>" + cartProduct.getRowNo().toString()
                            + "</td><td>" + cartProduct.getProductName()
                            + "</td><td>" + cartProduct.getQuantity().toString()
                            + "</td></tr>");
                }
                out.println("</Table>");
                out.println("<a href=\"/Session Tracking/Shopping.jsp\">Back to product page</a>");
                out.println("</body>");
                out.println("</html>");
            } catch (Exception e) {
                // TODO: handle exception
            } finally {
                out.close();
            }
        }
    }

}
