/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package DOMTraversal;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.traversal.DocumentTraversal;
import org.w3c.dom.traversal.NodeFilter;
import org.w3c.dom.traversal.NodeIterator;
import org.w3c.dom.traversal.TreeWalker;
import org.xml.sax.SAXException;

/**
 *
 * @author Leung
 */
public class Main {

    public void process(File xmlDoc) {
        try {
            // Create a DocumentBuilder object
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder parser = factory.newDocumentBuilder();
            // Check for the traversal module
            DOMImplementation docImpl = parser.getDOMImplementation();
            if (!docImpl.hasFeature("traversal", "2.0")) {
                System.out.println("A DOM implementation that supports traversal is required.");
                return;
            }
            // Read the document
            Document doc = parser.parse(xmlDoc);

            // Create NodeIterator
            DocumentTraversal traversal = (DocumentTraversal) doc;


            // print the document tree with NodeIterator
            NodeIterator nodeIter = traversal.createNodeIterator(
                    doc.getDocumentElement(), NodeFilter.SHOW_ELEMENT, null, true);
            System.out.println("Using : NodeIterator");
            printNodeIterator(nodeIter);

            // print the document tree with TreeWalker
            TreeWalker walker = traversal.createTreeWalker(
                    doc.getDocumentElement(), NodeFilter.SHOW_ELEMENT, null, true);
            System.out.println("Using : TreeWalker");
            printTreeWalker(walker, 0);

        } catch (SAXException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void printNodeAttribute(Node n) {
        if (n.hasAttributes()) {
            NamedNodeMap attrs = n.getAttributes();
            System.out.print(" ( ");
            for (int i = 0; i < attrs.getLength(); i++) {
                System.out.print(attrs.item(i).getNodeName() + " = " + attrs.item(i).getNodeValue());
                if (i < (attrs.getLength() - 1)) {
                    System.out.print(",");
                }
            }
            System.out.print(" ) ");
        }
    }

    private void printNodeIterator(NodeIterator nodeIter) {
        Node n;
        int indentation = 0;
        while ((n = nodeIter.nextNode()) != null) {
            if (n.getNodeType() == Node.ELEMENT_NODE) {
                indent(indentation);
                System.out.print("ELEMENT : " + n.getNodeName());

                printNodeAttribute(n);

                System.out.println();

                if (n.hasChildNodes()
                        && n.getChildNodes().item(1) != null) {
                    indentation += 2;
                    continue;
                } else {
                    Element parent = (Element) n.getParentNode();
                    if (parent != null) {
                        NodeList childs = parent.getChildNodes();
                        int len = childs.getLength();
                        Node lastChild = childs.item(len - 2);
                        if (n.isSameNode(lastChild) || n.isEqualNode(lastChild)) {
                            indentation -= 2;
                        }
                    }

                }
            }
        }
    }

    private void printTreeWalker(TreeWalker walker, int indentation) {

        // describe current node:
        Node parent = walker.getCurrentNode();
        indent(indentation);
        System.out.print("[-]Element "
                + ((Element) parent).getTagName());

        printNodeAttribute(parent);
        System.out.println();

        // traverse children:
        for (Node n = walker.firstChild();
                n != null;
                n = walker.nextSibling()) {
            printTreeWalker(walker, indentation + 2);
        } // return position to the current (level up):
        walker.setCurrentNode(parent);
    }

    private void indent(int n) {
        for (int i = 0; i
                < n; i++) {
            System.out.print(" ");
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        new Main().process(new File(args[0]));

    }
}
