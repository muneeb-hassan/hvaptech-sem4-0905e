/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package a6_xpath;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author Leung
 */
public class Main {

// <editor-fold defaultstate="collapsed" desc="Utils">
    private void printNode(Node node, int indentation) {
        if (node.getNodeType() == Node.ELEMENT_NODE) {
            indent(indentation);
            System.out.print(node.getNodeName());
            printNodeAttribute(node);
            System.out.print(" = " + node.getTextContent());
            System.out.println();
            if (node.hasChildNodes()) {
                NodeList childs = node.getChildNodes();
                for (int i = 0; i < childs.getLength(); i++) {
                    printNode(childs.item(i), indentation + 2);
                }
            } else {
            }

            indentation -= 2;
        }
    }

    private void printNodeAttribute(Node n) {
        if (n.hasAttributes()) {
            NamedNodeMap attrs = n.getAttributes();
            System.out.print(" ( ");
            for (int i = 0; i < attrs.getLength(); i++) {
                System.out.print(attrs.item(i).getNodeName() + " = " + attrs.item(i).getNodeValue());
                if (i < (attrs.getLength() - 1)) {
                    System.out.print(",");
                }
            }
            System.out.print(" ) ");
        }
    }

    private void indent(int n) {
        for (int i = 0; i
                < n; i++) {
            System.out.print(" ");
        }
    }// </editor-fold>

    public void process(File f) {
        try {
            // Parse xml file
            DocumentBuilder parser = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document doc = parser.parse(f);
            // Create a XPath object
            XPath xp = XPathFactory.newInstance().newXPath();
            String expr = "";
            XPathExpression xpe;
            Node node;
            NodeList list;

            // 1
            expr = "//book[last()]";
            // Compile the expression
            xpe = xp.compile(expr);
            System.out.println(String.format(
                    "1. The last <book> element : [%s]", expr));
            node = (Node) xpe.evaluate(doc, XPathConstants.NODE);
            System.out.println(node.getNodeName());
            System.out.println();

            // 2
            expr = "//book/author[last()]";
            // Compile the expression
            xpe = xp.compile(expr);
            System.out.println(String.format(
                    "2. The last <author> child of each book : [%s]", expr));
            list = (NodeList) xpe.evaluate(doc, XPathConstants.NODESET);
            System.out.println("=> The document has " + list.getLength() + " elements");
            for (int i = 0; i < list.getLength(); i++) {
                System.out.println(list.item(i).getNodeName());
            }
            System.out.println();

            // 3
            expr = "(//book/author)[last()]";
            xpe = xp.compile(expr);
            System.out.println(String.format(
                    "3. The last <author> from entire set <author> children of book : [%s]", expr));
            node = (Node) xpe.evaluate(doc, XPathConstants.NODE);
            System.out.println(node.getNodeName());
            System.out.println();

            // 4
            expr = "//book[excerpt]";
            // Compile the expression
            xpe = xp.compile(expr);
            System.out.println(String.format(
                    "4. All <book> contain <excerpt> child : [%s]", expr));
            list = (NodeList) xpe.evaluate(doc, XPathConstants.NODESET);
            System.out.println("=> The document has " + list.getLength() + " elements");
            for (int i = 0; i < list.getLength(); i++) {
                System.out.println(list.item(i).getNodeName());
            }
            System.out.println();

            // 5
            expr = "//book[excerpt]//title";
            // Compile the expression
            xpe = xp.compile(expr);
            System.out.println(String.format(
                    "5. All <title> are children of <book> contain <excerpt> : [%s]", expr));
            list = (NodeList) xpe.evaluate(doc, XPathConstants.NODESET);
            System.out.println("=> The document has " + list.getLength() + " elements");
            System.out.println();

            // 6
            expr = "//book[excerpt]/author[degree]";
            // Compile the expression
            xpe = xp.compile(expr);
            System.out.println(String.format(
                    "6. All <author> contain <degree> and are children of <book> contain <excerpt> : [%s]", expr));
            list = (NodeList) xpe.evaluate(doc, XPathConstants.NODESET);
            System.out.println("=> The document has " + list.getLength() + " elements");
            for (int i = 0; i < list.getLength(); i++) {
                System.out.println(list.item(i).getNodeName());
            }
            System.out.println();

            // 7
            expr = "//book/author[degree]";
            // Compile the expression
            xpe = xp.compile(expr);
            System.out.println(String.format(
                    "7. All <book> contain <author> children that in turn contain <degree>  : [%s]", expr));
            list = (NodeList) xpe.evaluate(doc, XPathConstants.NODESET);
            System.out.println("=> The document has " + list.getLength() + " elements");
            for (int i = 0; i < list.getLength(); i++) {
                System.out.println(list.item(i).getNodeName());
            }
            System.out.println();

            // 8
            expr = "//author[degree and award]";
            // Compile the expression
            xpe = xp.compile(expr);
            System.out.println(String.format(
                    "8. All <author> contain <degree> and <award> : [%s]", expr));
            list = (NodeList) xpe.evaluate(doc, XPathConstants.NODESET);
            System.out.println("=> The document has " + list.getLength() + " elements");
            for (int i = 0; i < list.getLength(); i++) {
                System.out.println(list.item(i).getNodeName());
            }
            System.out.println();

            // 10
            expr = "//author[(degree or award) and publication]";
            // Compile the expression
            xpe = xp.compile(expr);
            System.out.println(String.format(
                    "10. All <author> contain <degree> or <award> and <publication> as children: [%s]", expr));
            list = (NodeList) xpe.evaluate(doc, XPathConstants.NODESET);
            System.out.println("=> The document has " + list.getLength() + " elements");
            for (int i = 0; i < list.getLength(); i++) {
                System.out.println(list.item(i).getNodeName());
            }
            System.out.println();

            // 11
            expr = "//author[degree and not(publication)]";
            // Compile the expression
            xpe = xp.compile(expr);
            System.out.println(String.format(
                    "11. All <author> contain <degree> and contain no <publication> : [%s]", expr));
            list = (NodeList) xpe.evaluate(doc, XPathConstants.NODESET);
            System.out.println("=> The document has " + list.getLength() + " elements.");
            for (int i = 0; i < list.getLength(); i++) {
                System.out.println(list.item(i).getNodeName());
            }
            System.out.println();

            // 12
            expr = "//author[publication and (not(degree or award))]";
            // Compile the expression
            xpe = xp.compile(expr);
            System.out.println(String.format(
                    "12. All <author> contain <publication> and contain neither <degree> nor <award> : [%s]", expr));
            list = (NodeList) xpe.evaluate(doc, XPathConstants.NODESET);
            System.out.println("=> The document has " + list.getLength() + " elements.");
            for (int i = 0; i < list.getLength(); i++) {
                System.out.println(list.item(i).getNodeName());
            }
            System.out.println();

            // 13
            expr = "//author[//last-name = 'Bob']";
            // Compile the expression
            xpe = xp.compile(expr);
            System.out.println(String.format(
                    "13. All <author> contain <last-name> with the value 'Bob' : [%s]", expr));
            list = (NodeList) xpe.evaluate(doc, XPathConstants.NODESET);
            System.out.println("=> The document has " + list.getLength() + " elements.");
            for (int i = 0; i < list.getLength(); i++) {
                System.out.println(list.item(i).getNodeName());
            }
            System.out.println();

            // 14
            expr = "//author[last-name[1] = 'Bob']";
            // Compile the expression
            xpe = xp.compile(expr);
            System.out.println(String.format(
                    "14. <author> where the first <last-name> has the value 'Bob' : [%s]", expr));
            list = (NodeList) xpe.evaluate(doc, XPathConstants.NODESET);
            System.out.println("=> The document has " + list.getLength() + " elements.");
            for (int i = 0; i < list.getLength(); i++) {
                System.out.println(list.item(i).getNodeName());
            }
            System.out.println();

            // 15
            expr = "//author[last-name[1] = 'Bob']";
            // Compile the expression
            xpe = xp.compile(expr);
            System.out.println(String.format(
                    "15. <author> where the first <last-name> has the value 'Bob' : [%s]", expr));
            list = (NodeList) xpe.evaluate(doc, XPathConstants.NODESET);
            System.out.println("=> The document has " + list.getLength() + " elements.");
            for (int i = 0; i < list.getLength(); i++) {
                System.out.println(list.item(i).getNodeName());
            }
            System.out.println();

            // 16
            expr = "//degree[@from != 'Harvard']";
            // Compile the expression
            xpe = xp.compile(expr);
            System.out.println(String.format(
                    "16. All <degree> where the [form] attribute not equal 'Harvard' : [%s]", expr));
            list = (NodeList) xpe.evaluate(doc, XPathConstants.NODESET);
            System.out.println("=> The document has " + list.getLength() + " elements.");
            for (int i = 0; i < list.getLength(); i++) {
                System.out.println(list.item(i).getNodeName());
            }
            System.out.println();

            // 17
            expr = "//author[. = 'Matthew Bob']";
            // Compile the expression
            xpe = xp.compile(expr);
            System.out.println(String.format(
                    "17. All <author> whose value is 'Matthew Bob' : [%s]", expr));
            list = (NodeList) xpe.evaluate(doc, XPathConstants.NODESET);
            System.out.println("=> The document has " + list.getLength() + " elements.");
            for (int i = 0; i < list.getLength(); i++) {
                System.out.println(list.item(i).getNodeName());
            }
            System.out.println();

            // 18
            expr = "//author[(last-name = 'Bob') and (../price > 50)]";
            // Compile the expression
            xpe = xp.compile(expr);
            System.out.println(String.format(
                    "18. All <author> contain <last-name> = 'Bob' and <price> sibling is greater than 50 : [%s]", expr));
            list = (NodeList) xpe.evaluate(doc, XPathConstants.NODESET);
            System.out.println("=> The document has " + list.getLength() + " elements.");
            for (int i = 0; i < list.getLength(); i++) {
                System.out.println(list.item(i).getNodeName());
            }
            System.out.println();

            // 19
            expr = "//book[ position() < 4 ]";
            // Compile the expression
            xpe = xp.compile(expr);
            System.out.println(String.format(
                    "19. The first three books. : [%s]", expr));
            list = (NodeList) xpe.evaluate(doc, XPathConstants.NODESET);
            System.out.println("=> The document has " + list.getLength() + " elements.");
            for (int i = 0; i < list.getLength(); i++) {
                System.out.println(list.item(i).getNodeName());
            }
            System.out.println();

            // 20
            expr = "//author[last-name != 'Bob']";
            // Compile the expression
            xpe = xp.compile(expr);
            System.out.println(String.format(
                    "20. All <author> not contain <last-name> has the value 'Bob' : [%s]", expr));
            list = (NodeList) xpe.evaluate(doc, XPathConstants.NODESET);
            System.out.println("=> The document has " + list.getLength() + " elements.");
            for (int i = 0; i < list.getLength(); i++) {
                System.out.println(list.item(i).getNodeName());
            }
            System.out.println();

            // 21
            expr = "//author[first-name = 'Bob']";
            // Compile the expression
            xpe = xp.compile(expr);
            System.out.println(String.format(
                    "21. All <author> has <first-name> child with the value 'Bob' : [%s]", expr));
            list = (NodeList) xpe.evaluate(doc, XPathConstants.NODESET);
            System.out.println("=> The document has " + list.getLength() + " elements.");
            for (int i = 0; i < list.getLength(); i++) {
                System.out.println(list.item(i).getNodeName());
            }
            System.out.println();

            // 22
            expr = "//author[* = 'Bob']";
            // Compile the expression
            xpe = xp.compile(expr);
            System.out.println(String.format(
                    "22. All <author> has a any child whose value is 'Bob' : [%s]", expr));
            list = (NodeList) xpe.evaluate(doc, XPathConstants.NODESET);
            System.out.println("=> The document has " + list.getLength() + " elements.");
            for (int i = 0; i < list.getLength(); i++) {
                System.out.println(list.item(i).getNodeName());
            }
            System.out.println();

            // 23
            expr = "//author[ (last-name = 'Bob') and (first-name = 'Joe')]";
            // Compile the expression
            xpe = xp.compile(expr);
            System.out.println(String.format(
                    "23. All <author> has <last-name> child with the value 'Bob' and "
                    + "<first-name> child with the value 'Joe' : [%s]", expr));
            list = (NodeList) xpe.evaluate(doc, XPathConstants.NODESET);
            System.out.println("=> The document has " + list.getLength() + " elements.");
            for (int i = 0; i < list.getLength(); i++) {
                System.out.println(list.item(i).getNodeName());
            }
            System.out.println();

            // 24
            expr = "//price[@intl = 'Canada']";
            // Compile the expression
            xpe = xp.compile(expr);
            System.out.println(String.format(
                    "24. All <price> which have an [intl] attribute equal to 'Canada': [%s]", expr));
            list = (NodeList) xpe.evaluate(doc, XPathConstants.NODESET);
            System.out.println("=> The document has " + list.getLength() + " elements.");
            for (int i = 0; i < list.getLength(); i++) {
                System.out.println(list.item(i).getNodeName() + " = " + list.item(i).getTextContent());
            }
            System.out.println();

            // 25
            expr = "//degree[ position() < 3 ]";
            // Compile the expression
            xpe = xp.compile(expr);
            System.out.println(String.format(
                    "25. The first two <degree> that are children of the context node : [%s]", expr));
            list = (NodeList) xpe.evaluate(doc, XPathConstants.NODESET);
            System.out.println("=> The document has " + list.getLength() + " elements.");
            for (int i = 0; i < list.getLength(); i++) {
                System.out.println(list.item(i).getNodeName() + " = " + list.item(i).getTextContent());
            }
            System.out.println();

            // 26
            expr = "//p/text()[2]";
            // Compile the expression
            xpe = xp.compile(expr);
            System.out.println(String.format(
                    "26. The second text node in each <p> element : [%s]", expr));
            list = (NodeList) xpe.evaluate(doc, XPathConstants.NODESET);
            System.out.println("=> The document has " + list.getLength() + " elements.");
            for (int i = 0; i < list.getLength(); i++) {
                System.out.println(list.item(i).getNodeValue());
            }
            System.out.println();

            // 27
            expr = "ancestor::book[1]";
            // Compile the expression
            xpe = xp.compile(expr);
            System.out.println(String.format(
                    "27. The nearest <book> ancestor of the context node : [%s]", expr));
            list = (NodeList) xpe.evaluate(doc, XPathConstants.NODESET);
            System.out.println("=> The document has " + list.getLength() + " elements.");
            for (int i = 0; i < list.getLength(); i++) {
                System.out.println(list.item(i).getNodeName());
            }
            System.out.println();

            // 28
            expr = "ancestor::book[author][1]";
            // Compile the expression
            xpe = xp.compile(expr);
            System.out.println(String.format(
                    "28. The nearest <book> ancestor of the context node and this <book>"
                    + " has an <author> child : [%s]", expr));
            list = (NodeList) xpe.evaluate(doc, XPathConstants.NODESET);
            System.out.println("=> The document has " + list.getLength() + " elements.");
            for (int i = 0; i < list.getLength(); i++) {
                System.out.println(list.item(i).getNodeName());
            }
            System.out.println();

            // 29
            expr = "ancestor::author[parent::book][1]";
            // Compile the expression
            xpe = xp.compile(expr);
            System.out.println(String.format(
                    "29. The nearest <author> ancestor in the current context and this <author> element is "
                    + "a child of a <book> element : [%s]", expr));
            list = (NodeList) xpe.evaluate(doc, XPathConstants.NODESET);
            System.out.println("=> The document has " + list.getLength() + " elements.");
            for (int i = 0; i < list.getLength(); i++) {
                System.out.println(list.item(i).getNodeName());
            }
            System.out.println();

        } catch (SAXException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (XPathExpressionException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        new Main().process(new File(args[0]));
    }
}
