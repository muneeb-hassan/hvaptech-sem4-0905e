package coreservlets;

import javax.servlet.http.*;
import org.apache.struts.action.*;

public class FormatFormBean extends ActionForm {

	private static final long serialVersionUID = 1L;

	private String titleSize = "";
	private String headingSize = "";
	private String bodySize = "";
	private String bgColor = "";
	private String fgColor = "";
	private String warning = "";

	public String getTitleSize() {
		return (titleSize);
	}

	public void setTitleSize(String titleSize) {
		this.titleSize = titleSize;
	}

	public String getHeadingSize() {
		return (headingSize);
	}

	public void setHeadingSize(String headingSize) {
		this.headingSize = headingSize;
	}

	public String getBodySize() {
		return (bodySize);
	}

	public void setBodySize(String bodySize) {
		this.bodySize = bodySize;
	}

	public String getBgColor() {
		return (bgColor);
	}

	public void setBgColor(String bgColor) {
		this.bgColor = bgColor;
	}

	public String getFgColor() {
		return (fgColor);
	}

	public void setFgColor(String fgColor) {
		this.fgColor = fgColor;
	}

	public String getWarning() {
		return (warning);
	}

	public void addWarning(String warning) {
		this.warning = this.warning + "<B><FONT COLOR=RED>" + warning
				+ "!</FONT></B><BR>";
	}

	public void resetWarning() {
		warning = "";
	}

	public void reset(ActionMapping mapping, HttpServletRequest request) {
		// reset
		resetWarning();
	}

	public boolean isMissing(String value) {
		return ((value == null) || (value.trim().equals("")));
	}
}
