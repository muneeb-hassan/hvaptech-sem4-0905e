package coreservlets;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

public class ShowSampleAction extends Action {

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		FormatFormBean formatBean = (FormatFormBean) form;
		ActionForward forward = mapping.findForward("success");

		if (formatBean.isMissing(formatBean.getTitleSize())) {
			formatBean.addWarning("Missing Title Size");
			forward = mapping.findForward("missing-data");
		}

		if (formatBean.isMissing(formatBean.getHeadingSize())) {
			formatBean.addWarning("Missing Heading Size");
			forward = mapping.findForward("missing-data");
		}

		if (formatBean.isMissing(formatBean.getBodySize())) {
			formatBean.addWarning("Missing Body Size");
			forward = mapping.findForward("missing-data");
		}

		if (formatBean.isMissing(formatBean.getBgColor())) {
			formatBean.addWarning("Missing Background Color");
			forward = mapping.findForward("missing-data");
		}

		if (formatBean.isMissing(formatBean.getFgColor())) {
			formatBean.addWarning("Missing Foreground Color");
			forward = mapping.findForward("missing-data");
		} else if (formatBean.getFgColor().equals(formatBean.getBgColor())) {
			formatBean.addWarning("Foreground and Background Identical!");
			forward = mapping.findForward("missing-data");
		}

		return (forward);
	}
}
