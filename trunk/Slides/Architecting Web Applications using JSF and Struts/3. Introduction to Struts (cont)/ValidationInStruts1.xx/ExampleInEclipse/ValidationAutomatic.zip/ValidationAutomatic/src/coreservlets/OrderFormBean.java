package coreservlets;

import org.apache.struts.validator.*;

public class OrderFormBean extends ValidatorForm {

	private static final long serialVersionUID = 1L;
	
	private String firstName = "";
	private String lastName = "";
	private String age = "";
	private String address = "";
	private String zipCode = "";
	private String creditCardNumber = "";
	private String email = "";

	public String getFirstName() {
		return (firstName);
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return (lastName);
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAge() {
		return (this.age);
	}

	public void setAge(String lastName) {
		this.age = lastName;
	}

	public String getAddress() {
		return (address);
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getZipCode() {
		return (zipCode);
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getCreditCardNumber() {
		return (creditCardNumber);
	}

	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}

	public String getEmail() {
		return (email);
	}

	public void setEmail(String email) {
		this.email = email;
	}
}
