package coreservlets;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

public class FormatFormBean extends ActionForm {

	/**
	 * classID. 
	 */
	private static final long serialVersionUID = 1L;
	
	private String titleSize = "";
	private String headingSize = "";
	private String bodySize = "";
	private String bgColor = "";
	private String fgColor = "";

	public String getTitleSize() {
		return (titleSize);
	}

	public void setTitleSize(String titleSize) {
		this.titleSize = titleSize;
	}

	public String getHeadingSize() {
		return (headingSize);
	}

	public void setHeadingSize(String headingSize) {
		this.headingSize = headingSize;
	}

	public String getBodySize() {
		return (bodySize);
	}

	public void setBodySize(String bodySize) {
		this.bodySize = bodySize;
	}

	public String getBgColor() {
		return (bgColor);
	}

	public void setBgColor(String bgColor) {
		this.bgColor = bgColor;
	}

	public String getFgColor() {
		return (fgColor);
	}

	public void setFgColor(String fgColor) {
		this.fgColor = fgColor;
	}

	public ActionErrors validate(ActionMapping mapping,
			HttpServletRequest request) {

		ActionErrors errors = new ActionErrors();

		if (isMissing(getTitleSize())) {
			errors.add("title", new ActionMessage("titleSize.required"));
		}

		if (isMissing(getHeadingSize())) {
			errors.add("heading", new ActionMessage("headingSize.required",
					"Parameterized: Heading size"));
		}
		
		if (isMissing(getBodySize())) {
			errors.add("body", new ActionMessage("bodySize.required"));
		}

		if (isMissing(getBgColor())) {
			errors.add("bg", new ActionMessage("bgColor.required"));
		}

		if (isMissing(getFgColor())) {
			errors.add("fg", new ActionMessage("fgColor.required"));
		} else if (getFgColor().equals(getBgColor())) {
			errors.add("fg", new ActionMessage("colors.notMatch"));
		}

		return (errors);
	}

	private boolean isMissing(String value) {
		return ((value == null) || (value.trim().equals("")));
	}
}
